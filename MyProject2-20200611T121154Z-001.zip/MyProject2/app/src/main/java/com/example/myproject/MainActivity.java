package com.example.myproject;

import androidx.appcompat.app.AppCompatActivity;


import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputFilter;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    // global variables
    Handler handler = new Handler();
    Runnable runnable;
    private float attended = 0;
    private float bunked = 0;
    private float mpercentage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button greenPlusButton = findViewById(R.id.greenPlusButton);
        final Button greenMinusButton = findViewById(R.id.greenMinusButton);
        final Button redPlusButton = findViewById(R.id.redPlusButton);
        final Button redMinusButton = findViewById(R.id.redMinusButton);
        EditText et = findViewById(R.id.goal_text_view);
        et.setFilters(new InputFilter[]{new InputFilterMinMax("1", "99")});
        //
        greenPlusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                attended += 1;
                set();

            }
        });
        greenMinusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (attended == 0) {
                    return;
                }
                attended -= 1;
                set();

            }
        });
        redPlusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bunked += 1;
                set();
            }
        });
        redMinusButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (bunked == 0) {
                    return;
                }
                bunked -= 1;
                set();
            }
        });
        greenPlusButton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                runnable = new Runnable() {
                    @Override
                    public void run() {
                        if (!greenPlusButton.isPressed()) return;
                        attended += 1;
                        set();
                        handler.postDelayed(runnable, 100);
                    }
                };
                handler.postDelayed(runnable, 100);
                return true;
            }
        });
        greenMinusButton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                runnable = new Runnable() {
                    @Override
                    public void run() {
                        if (!greenMinusButton.isPressed()) return;
                        if (attended == 0) return;
                        attended -= 1;
                        set();
                        handler.postDelayed(runnable, 100);
                    }
                };
                handler.postDelayed(runnable, 100);
                return true;
            }
        });
        redPlusButton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                runnable = new Runnable() {
                    @Override
                    public void run() {
                        if (!redPlusButton.isPressed()) return;
                        bunked += 1;
                        set();
                        handler.postDelayed(runnable, 100);
                    }
                };
                handler.postDelayed(runnable, 100);
                return true;
            }
        });
        redMinusButton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                runnable = new Runnable() {
                    @Override
                    public void run() {
                        if (!redMinusButton.isPressed()) return;
                        if (bunked == 0) return;
                        bunked -= 1;
                        set();
                        handler.postDelayed(runnable, 100);
                    }
                };
                handler.postDelayed(runnable, 100);
                return true;
            }
        });
    }

    public void set() {
        setAttended();
        setBunked();
        setPercentage();
        setTotalClasses();
        setSummary();
        setGoal(getGoalValue());
    }

    protected void onResume() {
        super.onResume();
        SharedPreferences pref = getSharedPreferences("My Shared Preferences", MODE_PRIVATE);
        attended = pref.getFloat("attended", 0);
        bunked = pref.getFloat("bunked", 0);
        setGoal(pref.getFloat("goal", 0));
        setStringSummary(pref.getString("summary", ""));
        setAttended();
        setBunked();
        setPercentage();
        setTotalClasses();
    }

    protected void onPause() {
        super.onPause();
        SharedPreferences pref = getSharedPreferences("My Shared Preferences", MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putFloat("attended", attended);
        editor.putFloat("bunked", bunked);
        editor.putFloat("goal", getGoalValue());
        editor.putString("summary", getNote());
        editor.apply();
    }

    //wrote this method to save the string in prference manager
    public String getNote() {
        TextView textView = findViewById(R.id.summary_text_view);
        return textView.getText().toString();
    }

    //to keep the string on resume
    public void setStringSummary(String s) {
        TextView textView = findViewById(R.id.summary_text_view);
        textView.setText(s);
    }

    //calculates and return current percentage as string
    public String calculatePercentage() {
        double total = attended + bunked;
        if (total != 0) {
            double percent = ((attended * 1.0) / total);
            double result = percent * 100;
            double roundOff = Math.round(result * 100.00) / 100.00;
            mpercentage = (float) roundOff;
            return Double.toString(roundOff);
        } else {
            return "0.00";
        }
    }

    public void setPercentage() {
        TextView percentageTextView = findViewById(R.id.percentage_text_view);
        percentageTextView.setText(calculatePercentage());
    }

    public void setTotalClasses() {
        TextView totalClasses = findViewById(R.id.total_classes_text_view);
        totalClasses.setText(String.valueOf(Math.round(attended + bunked)));
    }

    //sets the attended field
    public void setAttended() {
        TextView attended_text = findViewById(R.id.attended_text);
        attended_text.setText(String.valueOf(Math.round(attended)));
    }

    //sets the bunked class
    public void setBunked() {
        TextView bunked_text = findViewById(R.id.bunked_text);
        bunked_text.setText(String.valueOf(Math.round(bunked)));
    }

    public void setGoal(float g) {
        EditText editText = findViewById(R.id.goal_text_view);
        editText.setText(String.valueOf(Math.round(g)));

    }

    // sets the summary to the last textview in the layout
    public void setSummary() {
        TextView textView = findViewById(R.id.summary_text_view);
        textView.setText(createSummary());

    }

    //gets the goal value from the edit text field and its default vaue is 75
    public float getGoalValue() {
        EditText editText = findViewById(R.id.goal_text_view);
        String s = editText.getText().toString();
        if (s.matches("")) {
            return 75;
        } else {
            return Float.parseFloat(s);
        }
    }

    //create the summary string
    public String createSummary() {
        int noOfClasses = noOfClasses();
        if (mpercentage > getGoalValue()) {
            if ((noOfClasses - 1) == 0) {
                return "You cannot miss the next class";
            } else {
                return "You can bunk the next " + (noOfClasses - 1) + " class(es)";
            }
        } else {
            if (noOfClasses == 0) {
                return "You cannot miss the next class";
            } else {
                return "Attend next " + (noOfClasses) + " class(es)";
            }
        }

    }
    //calculates no.of classes

    public float caluculateLocalPercentage(float a, float b) {
        return (((a) / (a + b) * 100));
    }

    public int noOfClasses() {
        int noOfClasses = 0;
        float localAttended = attended;
        float localBunked = bunked;
        float goalPercent = getGoalValue();
        float currentPercent = mpercentage;
        if (currentPercent > goalPercent) {
            while (currentPercent > goalPercent) {
                localBunked += 1;
                currentPercent = caluculateLocalPercentage(localAttended, localBunked);

                noOfClasses += 1;
            }
            return noOfClasses;
        } else if (currentPercent < goalPercent) {
            while (currentPercent < goalPercent) {
                currentPercent = caluculateLocalPercentage(localAttended, localBunked);
                localAttended += 1;
                noOfClasses += 1;
            }
            return (noOfClasses - 1);
        } else {
            return 0;
        }

    }
    public void tick(View v)
    {
        set();
        EditText editText = findViewById(R.id.goal_text_view);
        editText.setCursorVisible(false);
        InputMethodManager inputManager = (InputMethodManager)
                getSystemService(this.INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
                InputMethodManager.HIDE_NOT_ALWAYS);
    }


    public void cursorOn(View v)
    {
        EditText editText = findViewById(R.id.goal_text_view);
        editText.setCursorVisible(true);
    }


        }
